// get weather data in bandung today
function getWeather() {
	const xhr = new XMLHttpRequest();
	xhr.open('GET', 'https://api.openweathermap.org/data/2.5/weather?q=bandung&appid=b1b35bba8b434a28a0be2a3e1071ae5b');
	xhr.send();

	xhr.onload = function() {
		if(xhr.status === 200) {
			const data = JSON.parse(xhr.responseText);
			document.write

            console.log(data);
          
        }
    }
}

getWeather();


//get weather data in bandung with fetch api
function getWeather2() {
    fetch('https://api.openweathermap.org/data/2.5/weather?q=bandung&appid=b1b35bba8b434a28a0be2a3e1071ae5b')
    .then(function(response) {
        return response.json();
    })
    .then(function(data) {
        document.write("<h2>Weather in Bandung</h2>");
        document.write("<p>Temperature : " + data.main.temp +" </p>");
        document.write("<p>Description : " + data.weather[0].description + "</p>");
    })
    .catch(function(error) {
        console.log(error);
    });
}

getWeather2();

// decorate function getWeather2()

